const tcpClient = require('./client.js'); // подключаем модуль client.js для управления статическим классом tcpClient
const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

const client = new tcpClient(); // создание статического экземпляра "client" класса tcpClient

client.onConnected = function() { 
    console.log('Connected')		//метод "onConnected", который выводит в консоль 'Connected' для экземпляра client 
}

client.onDisconnect = function() {
    console.log('Disconnected')		//метод "Disconnected", который выводит в консоль 'Disconnected' для экземпляра client 
}

client.onRecive = function(data) {
    console.log('Recive data: '+ data)	//метод "onRecive", который выводит в консоль 'Recive data: ' и полученные данные от клиента
}

client.onError = function(error) {
    console.log('Error: '+error)	//метод "onError", который выводит в консоль 'Error: ' и вывод ошибки клиента 
}

function resolveAfter2Seconds(x) {
    return new Promise(resolve => {
      setTimeout(() => {
        resolve(x);
      }, 2000);
    });
  }
  
async function f0() {
        await resolveAfter2Seconds();
        rl.question('Input data: ', (answer) => { //ввод данных с клавиатуры                       
        rl.close();
        client.send(answer);
    });     
}

function f1(){
  var reg_arr = ['first', 'second', 'third']; //массив, ячейки которого - это значения соотвественных регистров 
  for(let i = 0;i < 3;i++)
  {
    client.readoutput(reg_arr[i] + '\n');
  }
}

function f2(){
  var reg_arr = ['first']; //массив, ячейки которого - это значения соотвественных регистров 
  for(let i = 0;i < 1;i++)
  {
    client.readinput(reg_arr[i] + '\n');
  }
}

function f3(){
  var reg_arr = ['first', 'second', 'third', 'fourth']; //массив, ячейки которого - это значения соотвественных регистров 
  for(let i = 0;i < 4;i++)
  {
    client.writeoutput(reg_arr[i] + '\n');
  }
}

function f4(){
  var reg_arr = ['first', 'second', 'third', 'fourth']; //массив, ячейки которого - это значения соотвественных регистров 
  for(let i = 0;i < 4;i++)
  {
    client.writemultioutput(reg_arr[i] + '\n');
  }
}

function modbus_request(){
  f1();
  f2();
  f3();
  f4();
}

client.connect(1337, '127.0.0.1');	//выполнение экземпляром client метода "connect" (подключение к порту 3000 и адресу localhost(по умолчанию))
//f0();
modbus_request();
    
         
//client.send(answer);
 
//класс tcpClient, экземпляр этого класса client и 
//методы onConnected, onDisconnect, onRecive и onError также описаны в файле client.js (в констукторе)

