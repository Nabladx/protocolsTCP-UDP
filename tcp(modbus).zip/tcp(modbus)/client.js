const net = require('net'); //подключаем модуль "net" для управление статическим классом net


class tcpClient { //описание класса tcpClient
    constructor () { // конструктор
        this.client = new net.Socket(); // присвоение начального значения экземпляру client: метода Socket() класса net
        this.sended = null;
        this.onConnected = null; // присвоение начального значение функции onConnected: null
        this.onError = null; // присвоение начального значение функции onError: null
        this.onRecive = null; // присвоение начального значение функции onRecive: null
        this.onDisconnect = null; // присвоение начального значение функции onDisconnect: null
    }

    connect (port, host) { //описание метода "connect", в который передается порт(port) и адрес хоста(host)
        this.client.connect(port, host, () => { //инициализация функции "connect" для экземпляра client
            this.client.on('data', (data)=>{	//инициализация функции "on" для экземпляра client: работа с дата-файлами
						//инициализация функции "onRecive" для экземпляра client
						//на вход подаются "дата-файлы"
                if (this.onRecive) {		//если функция onRecive равна null, 
                    this.onRecive(data)		//то передать в эту функцию "дата-файлы"
                }
                else {					//иначе
                    console.log('Recive data: '+data)	//вывести в консоли "Recive data: " и полученные дата-файлы
                }
            });
            this.client.on('error', (error)=>{  //инициализация функции "on" для экземпляра client: работа с ошибками
                if (this.onError) {		//если функция "onError" равна нулю
                    this.onError(error)		//то передать в эту функцию "ошибку"
                }
                else {					//иначе
                    console.error('Error: '+error)	//вывести в консоли "Error: " и ошибку
                }
            });
            this.client.on('close', ()=>{	//инициализация функции "on" для экземпляра client: закрытие клиента
                if (this.onDisconnect) {	//если функция "onDisconnect" равна нулю
                    this.onDisconnect()		//то выполнить эту функцию
                }
                else {					//иначе
                    console.log('Connection closed')	//вывести в консоли "Connection closed"
                }
            });

            if (this.onConnected)		//если функция "onConnected" равна нулю
                this.onConnected();		//то выполнить эту функцию
            else 				//иначе
                console.log('connected');	//вывести в консоли "connected"
            
        });
    };

    send(answer){      
        this.client.write(answer);                            
    };

    readoutput(reg_arr){ //Эта команда используется для чтения значений дискретных выходов DO.
        //тут должен быть хедер, но я не знаю, что он из себя представляет (предполагаю, что адрес устройства и функциональный код)
        
        //запросить:
        //Адрес первого регистра Lo байт
        //Количество регистров Hi байт
        //Количество регистров Lo байт
        //console.log(reg_arr);
        this.client.write(reg_arr);
        this.client.on('data', (data)=>{
            this.onRecive(data);
        });
    };

    readinput(reg_arr){ //дискретный ввод
        //Значение регистра DI 0-1
        this.client.write(reg_arr);
        this.client.on('data', (data)=>{
            this.onRecive(data);
        });
    };

    writeoutput(reg_arr){ //дискретный вывод
        //Адрес регистра Hi байт
        //Адрес регистра Lo байт
        //Значение Hi байт
        //Значение Lo байт
        this.client.write(reg_arr);
        this.client.on('data', (data)=>{
            this.onRecive(data);
        });
    };

    writemultioutput(reg_arr){ //запись нескольких дискретных выводов
        //Адрес первого регистра Hi байт
        //Адрес первого регистра Lo байт
        //Кол-во записанных рег. Hi байт
        //Кол-во записанных рег. Lo байт
        this.client.write(reg_arr);
        this.client.on('data', (data)=>{
            this.onRecive(data);
        });
    };
}

module.exports = tcpClient;

