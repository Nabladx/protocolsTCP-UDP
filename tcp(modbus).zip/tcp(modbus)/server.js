var net = require('net');

var server = net.createServer(function(socket) {
	//socket.write('Echo server\r\n');
	socket.on('data', (data) => console.log(data.toString()));
	socket.write('data', (data) => console.log(data)); //здесь должено быть значение регистра
});

server.listen(1337, '127.0.0.1');
